/** Automatically generated file. DO NOT MODIFY */
package com.google.android.gms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}