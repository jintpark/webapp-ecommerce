package com.solodroid.ecommerce.analytics;

public class AnalyticsConfig {

    // true for enabling Google Analytics, should be true in production release
    public static final boolean ANALYTICS = true;

}
